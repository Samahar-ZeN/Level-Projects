from django.urls import path
from .views import *



urlpatterns=[
    path('home/',home_view,name='home'),
    path('home2/',home2_view,name='home2'),
    path('signup/',signup_view,name='signup'),
    path('login/',login_view,name='login'),
    path('logout/',logoutUser,name='logout'),
    path('store/',store,name='store'),
    path('cart/',cart,name='cart'),
    path('checkout/',checkout,name='checkout'),
    path('about/',about_view,name='about'),
    path('contact/',contact_view,name='contact'),
    path('help/',help_view,name='help'),


    path('update_item/',updateItem,name='update_item'),
    path('process_order/',processOrder, name="process_order"),
]